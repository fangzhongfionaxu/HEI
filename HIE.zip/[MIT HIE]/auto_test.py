import unittest
import automation

#IDEA IS TO ORGANIZE LISTS IN FILTER PROGRAMS ... IMPORT AUTOMATION.PY THEN USE WRITE FUNCTION 
info = ["john doe", "novartis", "co-founder", "9dd3kd"]
automation.writeToSheet_PEOPLE(info)