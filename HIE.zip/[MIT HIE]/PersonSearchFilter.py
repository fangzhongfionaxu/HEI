import csv
import automation

"""first implement reader then writer to organize what we find... let's figure out how to
scan csv files again first lol"""
"""writing files would be much better for this and more efficient..."""
"""depends on credibility of MIT Healthcares Startups file and pitchbook """
"""lists companies from pitchbook csv file, use people search to filter to MIT specific"""
def pitchbook_companies(filename):
    list = []
    with open(filename) as csvfile:
        lineReader = csv.DictReader(csvfile)
        for row in lineReader:
            list.append(row['company'])
    csvfile.close()
    return list


"""lists companies from UROP google sheet csv file"""
def urop_companies():
    list = []
    with open('MITHEALTHCARESTARTUPS.csv') as csvfile:
        lineReader = csv.DictReader(csvfile)
        for row in lineReader:
            list.append(row['Company Name'])
    csvfile.close()
    return list

"""compares both urop google sheet companies and pitchbook search companies"""
def inBoth(filename):
    hie_list = urop_companies()
    pitchbook_list = pitchbook_companies(filename)
    both_list = []
    
    for company in hie_list:
        if (company in pitchbook_list and company not in both_list):
            both_list.append(company)
        
    return both_list

def controlF_Alum(filename):
    list = inBoth(filename)
    for item in list:
        listFormatter(item, filename)
    
def listFormatter(comp, filename):
    with open(filename) as csvFile:
        lineReader = csv.DictReader(csvFile)
        for row in lineReader:
            result = []
            if (row['company'] == comp):
                result.append(row['first_name'])
                result.append(row['last_name'])
                result.append(row['middle_name'])
                result.append(row['gender'])
                result.append(row['institution'])
                result.append(row['company'])
                result.append(row['company_type'])
                result.append(position(comp, filename)) # returns single primary position
                result.append(row['position'])
                result.append(row['company_location'])
                result.append(row['company_state'])
                result.append(row['company_country'])
                result.append(row['company_website'])
                result.append(row['person_bio'])
                result.append(row['person_linkedin'])
                result.append(row['person_pbID'])
            if (len(result) > 0):
                automation.writeToSheet_PEOPLE(result)
    csvFile.close()

def position(comp, filename):
    with open(filename) as csvFile:
        lineReader = csv.DictReader(csvFile)
        preList = []
        position = ''
        for row in lineReader:
            if (row['company'] == comp):
                phrase = row['position']
                preList = phrase.replace(',', ' ').split(' ')

                for pos in preList:
                    if (pos.lower() == "co-founder" or pos.lower() == "founding"):
                        position = "Co-Founder"
                    elif (pos.lower() == "founder"):
                        position = "Founder"
    csvFile.close()
    return position

