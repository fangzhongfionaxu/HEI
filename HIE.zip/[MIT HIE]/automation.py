import os.path

from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build

from google.oauth2 import service_account

SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]
SERVICE_ACCOUNT_FILE = 'keys.json'

creds = None
creds = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=SCOPES)

# The IDs of all google sheets (PEOPLE, ENTITIES, )
TEST_DATABASE_ID = "11_j1Gsc8nxtS0BMmFo9rno0QoWWNzkCkFUxp9mJnh0g"
#the real google sheet ID... gonna instead separate by sheets in sheets.. or should we make separate sheets?
RELATION_DATABASE_ID = "1iWRk0v40g5UTYNy3C4MTXJiikIGmTJAqfmutvVKN3SQ"

service = build("sheets", "v4", credentials=creds)

# Call the Sheets API
sheet = service.spreadsheets()

#sets PEOPLE sheet database column headers

request = sheet.values().update(spreadsheetId=RELATION_DATABASE_ID, 
                                range="People!A1", valueInputOption="USER_ENTERED", 
                                body ={"majorDimension": "COLUMNS", "values": [["First Name"], 
                                                                            ["Last Name"], 
                                                                            ["Middle Name"], 
                                                                            ["Gender"],
                                                                            ["Institution"],
                                                                            ["Company"],
                                                                            ["Company Type"],
                                                                            ["Position"],
                                                                            ["Company Location"],
                                                                            ["Company State"],
                                                                            ["Company Country"],
                                                                            ["Company Website"],
                                                                            ["Person Bio"],
                                                                            ["LinkedIn"],
                                                                            ["Person pbID"]]}).execute()

#sets PROGRAMS/INITIATIVES sheet column headers

request = sheet.values().update(spreadsheetId=RELATION_DATABASE_ID, 
                                range="Programs/Initiatives!A1", valueInputOption="USER_ENTERED", 
                                body ={"majorDimension": "COLUMNS", "values": [["Program"], 
                                                                            ["Company"], 
                                                                            ["Position"], 
                                                                            ["Company_pbID"]]}).execute()
#sets INVESTORS sheet column headers
request = sheet.values().update(spreadsheetId=RELATION_DATABASE_ID, 
                                range="Investors!A1", valueInputOption="USER_ENTERED", 
                                body ={"majorDimension": "COLUMNS", "values": [["Investor"], 
                                                                            ["Current/Past"], 
                                                                            ["Company"], 
                                                                            ["Firm_pbID"],
                                                                            ["Company_pbID"]]}).execute()
#LIST FORMAT MUST BE ["NAME", "COMPANY", "POSITION", "PBID"]
#PPL DATABASE SPECIFIC
info = ["john doe", "novartis", "co-founder", "9dd3kd"]
def writeToSheet_PEOPLE(filename):
    request = sheet.values().append(spreadsheetId=TEST_DATABASE_ID, 
                                    range="Sheet1!A1", valueInputOption="USER_ENTERED", 
                                    body ={"majorDimension": "COLUMNS", "values": [[filename[0]], 
                                                                                [filename[1]],            
                                                                                [filename[2]], 
                                                                                [filename[3]],
                                                                                [filename[4]], 
                                                                                [filename[5]],            
                                                                                [filename[6]], 
                                                                                [filename[7]],
                                                                                [filename[8]], 
                                                                                [filename[9]],            
                                                                                [filename[10]], 
                                                                                [filename[11]],
                                                                                [filename[12]], 
                                                                                [filename[13]],            
                                                                                [filename[14]],
                                                                                [filename[15]], 
                                                                                ]}).execute()  
def writeToSheet_PROGRAMS(filename):   
    request = sheet.values().append(spreadsheetId=TEST_DATABASE_ID, 
                                    range="Sheet1!A1", valueInputOption="USER_ENTERED", 
                                    body ={"majorDimension": "COLUMNS", "values": [[filename[0]], 
                                                                                [filename[1]],            
                                                                                [filename[2]], 
                                                                                [filename[3]],
                                                                                [filename[4]], 
                                                                                [filename[5]],            
                                                                                [filename[6]], 
                                                                                [filename[7]],
                                                                                [filename[8]], 
                                                                                [filename[9]],            
                                                                                [filename[10]], 
                                                                                [filename[11]],
                                                                                [filename[12]], 
                                                                                [filename[13]],            
                                                                                [filename[14]],
                                                                                [filename[15]], 
                                                                                ]}).execute()            
    