from PersonSearchFilter import *

print("\nINSTRUCTIONS FOR USE: \n-ENSURE ALL NECESSARY FILES ARE WITHIN THE SAME FOLDER\n-Please adjust the columns of your Pitchbook .csv file to categorize your information under \'company\' (the company name) and \'position\' (the persons position) accurately and accordingly"
      + "\n\n*NOTE: this program assumes that Pitchbook's People Search function was utilized efficiently")

file = input("\nPlease enter the name of your csv file (ex. filename.csv)\n")
controlF(file)
