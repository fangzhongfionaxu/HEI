import csv

"""first implement reader then writer to organize what we find... let's figure out how to
scan csv files again first lol"""
"""writing files would be much better for this and more efficient..."""
"""depends on credibility of MIT Healthcares Startups file and pitchbook """
"""lists companies from pitchbook csv file, use people search to filter to MIT specific"""
def pitchbook_companies(filename):
    list = []
    with open(filename) as csvfile:
        lineReader = csv.DictReader(csvfile)
        for row in lineReader:
            list.append(row['company'])
    csvfile.close()
    return list



"""lists companies from UROP google sheet csv file"""
def urop_companies():
    list = []
    with open('MITHealthcareStartupsCopy.csv') as csvfile:
        lineReader = csv.DictReader(csvfile)
        for row in lineReader:
            list.append(row['Company Name'])
    csvfile.close()
    return list

"""compares both urop google sheet companies and pitchbook search companies"""
def inBoth(filename):
    hie_list = urop_companies()
    pitchbook_list = pitchbook_companies(filename)
    both_list = []
    
    for company in hie_list:
        for c in pitchbook_list:
            if (c == company and c not in both_list):
                both_list.append(c)
        
    return both_list

def controlF_Alum(filename):
    list = inBoth(filename)
    for item in list:
        print("company: " +item)
        print("relationship: " + relationship(item, filename)+"\n")
    
def relationship(comp, filename):
    relationship = ''
    with open(filename) as csvFile:
        lineReader = csv.DictReader(csvFile)
        for row in lineReader:
            if (row['company'] == comp):
                relationship = row['position']
    csvFile.close()
    return relationship    
