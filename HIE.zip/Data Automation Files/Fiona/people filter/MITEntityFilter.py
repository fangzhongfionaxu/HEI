import csv
from PersonSearchFilter import urop_companies
from PersonSearchFilter import pitchbook_companies
from PersonSearchFilter import inBoth

"""returns list of MIT programs listed in provided google sheet "Healthcare Innovation Ecosystem"""
def mit_EntityList():
    list = []
    with open('programslist.csv') as csvFile:
        lineReader = csv.DictReader(csvFile)
        for row in lineReader:
            if (row['Program'] not in list):
                list.append(row['Program'])
    csvFile.close()
    return list


"""returns list of associated programs"""
def program_search(filename, comp):
    with open(filename) as csvFile:
        lineReader = csv.DictReader(csvFile)
        for row in lineReader:
            if (row['company'] == comp):
                associated = entity_formatter(filename, comp)
    csvFile.close()
    return inEntityList(associated)

"""helper method for program_search, does actual comparison"""
def inEntityList(entitylist):
    list = []
    listOfPrograms = mit_EntityList()
    for item in entitylist:
        if(item in listOfPrograms):
            list.append(item)
    return list

"""formats all entities associated with said comp in list format"""
def entity_formatter(filename, comp):
    list = []
    with open(filename) as csvFile:
        lineReader = csv.DictReader(csvFile)
        for row in lineReader:
            if (row['company'] == comp):
                phrase = row['programs']
                list = phrase.strip().split(', ')
    csvFile.close()
    return list

def programs_toString(filename, comp):
    result = ""
    associated = program_search(filename, comp)
    for item in associated:
        result += item + ", "
    return result

def controlF_Entity(filename):
    list = inBoth(filename)
    for item in list:
        print("company: " + item)
        print("associated entities: " + programs_toString(filename, item) + "\n")